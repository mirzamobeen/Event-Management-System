﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PBL
{
    public partial class Participant : Window
    {
        // SqlConnection Object for Database Connection
        SqlConnection SqlCon = new SqlConnection(@"Data Source=SHAHZAIB\SQLEXPRESS;Initial Catalog=PBL;Integrated Security=True");

        // DataSet to hold data temporarily
        DataSet ds = new DataSet();

        // Constructor
        public Participant()
        {
            InitializeComponent();
        }

        // Clear Textboxes Method
        public void clearTextboxes()
        {
            tbName.Clear();
            tbEmail.Clear();
            tbPhone.Clear();
            tbEvent.Clear();
        }

        // Validation Method for Empty and Whitespace, along with specific pattern checks
        public bool validation()
        {
            if (String.IsNullOrEmpty(tbName.Text) || String.IsNullOrEmpty(tbEmail.Text) || String.IsNullOrEmpty(tbPhone.Text) || String.IsNullOrEmpty(tbEvent.Text))
            {
                return false;
            }
            else if (String.IsNullOrWhiteSpace(tbName.Text) || String.IsNullOrWhiteSpace(tbEmail.Text) || String.IsNullOrWhiteSpace(tbPhone.Text) || String.IsNullOrWhiteSpace(tbEvent.Text))
            {
                return false;
            }
            else if (!Regex.Match(tbName.Text, "^[a-zA-Z]+$").Success)
            {
                MessageBox.Show("Invalid Name Must only have English characters", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                clearTextboxes();
                return false;
            }
            else if (!Regex.Match(tbEmail.Text, "^[a-zA-Z0-9]+@(gmail.com|yahoo.com|hotmail.com)$").Success)
            {
                MessageBox.Show("Not a Valid Email", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                clearTextboxes();
                return false;
            }
            else if (!Regex.Match(tbPhone.Text, "^[0-9]+$").Success)
            {
                MessageBox.Show("Invalid Contact Must Only Have Numbers", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                clearTextboxes();
                return false;
            }
            return true;
        }

        // Button Click Event to Navigate to Main Window
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Main Home = new Main();
            Home.Show();
            this.Close();
        }

        // Button Click Event to Register Participant
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
                if (validation() == true)
                {
                    SqlCommand cmd1 = new SqlCommand("SELECT * FROM  Users_tb WHERE Phone = '" + tbPhone.Text + "'", SqlCon);
                    SqlDataAdapter da = new SqlDataAdapter(cmd1);
                    da.Fill(ds);
                    int i = ds.Tables[0].Rows.Count;

                    if (i > 0)
                    {
                        MessageBox.Show("Mobile Number: " + tbPhone.Text + "Already Exist");
                        ds.Clear();
                    }
                    else
                    {
                        SqlCommand cmd = new SqlCommand("insert into Participant values (@Name, @Email, @Phone, @EventID)", SqlCon);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@Name", tbName.Text);
                        cmd.Parameters.AddWithValue("@Email", tbEmail.Text);
                        cmd.Parameters.AddWithValue("@Phone", tbPhone.Text);
                        cmd.Parameters.AddWithValue("@EventID", tbEvent.Text);

                        SqlCon.Open();
                        cmd.ExecuteNonQuery();
                        SqlCon.Close();

                        MessageBox.Show("Participant Successfully Registered", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        clearTextboxes();

                        Main Home = new Main();
                        Home.Show();
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Some Fields are Empty.\nPlease fill them", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SqlCon.Close();
                clearTextboxes();
            }
        }

        // Button Click Event to Clear Textboxes
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            clearTextboxes();
        }

        // Button Click Event to Navigate to All_Participants Window
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            All_Participants viewall = new All_Participants();
            viewall.Show();
            this.Close();
        }
    }
}
