﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PBL
{
    /// <summary>
    /// Interaction logic for Feedback.xaml
    /// </summary>
    public partial class Feedback : Window
    {
        // SqlConnection Object for Database Connection
        SqlConnection SqlCon = new SqlConnection(@"Data Source=SHAHZAIB\SQLEXPRESS;Initial Catalog=PBL;Integrated Security=True");

        // Constructor
        public Feedback()
        {
            InitializeComponent();
        }

        // Clear Textboxes Method
        public void clearTextboxes()
        {
            tbName.Clear();
            tbEvent.Clear();
            tbParti.Clear();
            tbcomment.Clear();
            tbRate.Clear();
            agreeCheckbox.IsChecked = false;
        }

        // Validation Method for Empty and Whitespace
        public bool validation()
        {
            if (String.IsNullOrEmpty(tbName.Text) || String.IsNullOrEmpty(tbEvent.Text) || String.IsNullOrEmpty(tbParti.Text) || String.IsNullOrEmpty(tbcomment.Text) || String.IsNullOrEmpty(tbRate.Text))
            {
                return false;
            }
            if (String.IsNullOrWhiteSpace(tbName.Text) || String.IsNullOrWhiteSpace(tbEvent.Text) || String.IsNullOrWhiteSpace(tbParti.Text) || String.IsNullOrWhiteSpace(tbcomment.Text) || String.IsNullOrWhiteSpace(tbRate.Text))
            {
                return false;
            }
            return true;
        }

        // Button Click Event to Navigate to Main Window
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Main Home = new Main();
            Home.Show();
            this.Close();
        }

        // Button Click Event to Submit Feedback
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                if (agreeCheckbox.IsChecked == true)
                {
                    if (validation() == true)
                    {
                        SqlCommand cmd = new SqlCommand("INSERT INTO Feedback VALUES (@Name, @PartID, @EventID, @Comment, @Rate)", SqlCon);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@Name", tbName.Text);
                        cmd.Parameters.AddWithValue("@PartID", tbParti.Text);
                        cmd.Parameters.AddWithValue("@EventID", tbEvent.Text);
                        cmd.Parameters.AddWithValue("@Comment", tbcomment.Text);
                        cmd.Parameters.AddWithValue("@Rate", tbRate.Text);

                        SqlCon.Open();
                        cmd.ExecuteNonQuery();
                        SqlCon.Close();

                        MessageBox.Show("Thank You for Your Feedback", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        clearTextboxes();

                        Main Home = new Main();
                        Home.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Some Fields are Empty.\nPlease fill them", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please agree with the terms and conditions.", "Warning", MessageBoxButton.OK);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SqlCon.Close();
                clearTextboxes();
            }
        }

        // Event Handler for Checkbox Click
        private void agreeCheckbox_Click(object sender, RoutedEventArgs e)
        {
            // Additional handling can be added if needed
        }

        // Event Handler for Checkbox Checked
        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // Additional handling can be added if needed
        }

        // Event Handler for Hyperlink Click
        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            // Additional handling can be added if needed
        }
    }
}
