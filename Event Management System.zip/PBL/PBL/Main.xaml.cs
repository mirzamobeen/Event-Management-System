﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PBL
{
    public partial class Main : Window
    {
        // Database connection
        SqlConnection sqlCon = new SqlConnection(@"Data Source=SHAHZAIB\SQLEXPRESS;Initial Catalog=PBL;Integrated Security=True");

        // Constructor
        public Main()
        {
            InitializeComponent();
            // Load initial data into the grid
            LoadGrid();
        }

        // Load data into the grid
        public void LoadGrid()
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM Event", sqlCon))
                {
                    // Open the database connection
                    sqlCon.Open();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    // Fill the DataTable with data from the database
                    sda.Fill(dt);
                    // Set the data source for the datagrid
                    datagrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately (e.g., log, display error message)
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                // Close the database connection in the 'finally' block to ensure it's always closed
                sqlCon.Close();
            }
        }

        // Button click event to open the Event window
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Event EventWindow = new Event();
            EventWindow.Show();
            this.Close();
        }

        // Button click event to open the Participant window
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Participant PartWindow = new Participant();
            PartWindow.Show();
            this.Close();
        }

        // Button click event to open the Feedback window
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Feedback FeedWindow = new Feedback();
            FeedWindow.Show();
            this.Close();
        }

        // Button click event to log out and open the login window
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Window1 logout = new Window1();
            logout.Show();
            this.Close();
        }
    }
}
