﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace PBL
{
    public partial class Event : Window
    {
        // Database connection
        SqlConnection SqlCon = new SqlConnection(@"Data Source=SHAHZAIB\SQLEXPRESS;Initial Catalog=PBL;Integrated Security=True");

        // Constructor
        public Event()
        {
            InitializeComponent();
        }

        // Clear all textboxes
        public void clearTextboxes()
        {
            tbEName.Clear();
            tbVenue.Clear();
            tbDate.Clear();
            tbDescp.Clear();
            tbOrganizer.Clear();
            agreeCheckbox.IsChecked = false;
        }

        // Validate if all required fields are filled
        public bool validation()
        {
            if (String.IsNullOrEmpty(tbEName.Text) || String.IsNullOrEmpty(tbVenue.Text) || String.IsNullOrEmpty(tbDate.Text) || String.IsNullOrEmpty(tbDescp.Text) || String.IsNullOrEmpty(tbOrganizer.Text))
            {
                return false;
            }
            if (String.IsNullOrWhiteSpace(tbEName.Text) || String.IsNullOrWhiteSpace(tbVenue.Text) || String.IsNullOrWhiteSpace(tbDate.Text) || String.IsNullOrWhiteSpace(tbDescp.Text) || String.IsNullOrWhiteSpace(tbOrganizer.Text))
            {
                return false;
            }
            return true;
        }

        // Button click event to register the event
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                if (agreeCheckbox.IsChecked == true)
                {
                    if (validation() == true)
                    {
                        // SQL command to insert data into the Event table
                        SqlCommand cmd = new SqlCommand("INSERT INTO Event VALUES (@Title, @Descp, @Date, @UserID, @Venue)", SqlCon);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@Title", tbEName.Text);
                        cmd.Parameters.AddWithValue("@Venue", tbVenue.Text);
                        cmd.Parameters.AddWithValue("@Descp", tbDescp.Text);
                        cmd.Parameters.AddWithValue("@Date", tbDate.Text);
                        cmd.Parameters.AddWithValue("@UserID", tbOrganizer.Text);

                        // Open the database connection
                        SqlCon.Open();
                        // Execute the SQL command
                        cmd.ExecuteNonQuery();
                        // Close the database connection
                        SqlCon.Close();

                        // Display success message
                        MessageBox.Show("Event Successfully Registered", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        // Clear textboxes
                        clearTextboxes();

                        // Open the main window
                        Main Home = new Main();
                        Home.Show();
                        this.Close();
                    }
                    else
                    {
                        // Display error message for empty fields
                        MessageBox.Show("Some Fields are Empty.\nPlease fill them", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                else
                {
                    // Display warning if terms and conditions are not agreed
                    MessageBox.Show("Please agree with the terms and conditions.", "Warning", MessageBoxButton.OK);
                }
            }
            catch (SqlException ex)
            {
                // Display SQL exception message
                MessageBox.Show(ex.Message);
            }
            finally
            {
                // Close the database connection and clear textboxes in the 'finally' block
                SqlCon.Close();
                clearTextboxes();
            }
        }

        // Button click event to navigate to the main window
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Main Home = new Main();
            Home.Show();
            this.Close();
        }

        private void agreeCheckbox_Click(object sender, RoutedEventArgs e)
        {
            // Additional logic can be added here if needed
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // Additional logic can be added here if needed
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            // Additional logic can be added here if needed
        }

        // Button click event to clear textboxes
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            clearTextboxes();
        }
    }
}
