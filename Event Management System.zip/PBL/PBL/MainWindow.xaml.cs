﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Xml.Linq;
using System.Text.RegularExpressions;

namespace PBL
{
    public partial class MainWindow : Window
    {
        // SqlConnection Object for Database Connection
        SqlConnection SqlCon = new SqlConnection(@"Data Source=SHAHZAIB\SQLEXPRESS;Initial Catalog=PBL;Integrated Security=True");

        // DataSet to hold data temporarily
        DataSet ds = new DataSet();

        // Constructor
        public MainWindow()
        {
            InitializeComponent();
        }

        // Clear Textboxes Method
        public void clearTextboxes()
        {
            tbName.Clear();
            tbEmail.Clear();
            tbPassword.Clear();
            tbPhone.Clear();
            agreeCheckbox.IsChecked = false;
        }

        // Validation Method for Empty and Whitespace, along with specific pattern checks
        public bool validation()
        {
            if (String.IsNullOrEmpty(tbName.Text) || String.IsNullOrEmpty(tbEmail.Text) || String.IsNullOrEmpty(tbPassword.Password) || String.IsNullOrEmpty(tbPhone.Text))
            {
                return false;
            }
            if (String.IsNullOrWhiteSpace(tbName.Text) || String.IsNullOrWhiteSpace(tbEmail.Text) || String.IsNullOrWhiteSpace(tbPassword.Password) || String.IsNullOrWhiteSpace(tbPhone.Text))
            {
                return false;
            }

            else if (!Regex.Match(tbName.Text, "^[a-zA-Z]+$").Success)
            {
                MessageBox.Show("Invalid Name Must only have English characters", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                clearTextboxes();
                return false;
            }
            else if (!Regex.Match(tbEmail.Text, "^[a-zA-Z0-9]+@(gmail.com|yahoo.com|hotmail.com)$").Success)
            {
                MessageBox.Show("Not a Valid Email", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                clearTextboxes();
                return false;
            }
            else if (!Regex.Match(tbPhone.Text, "^[0-9]+$").Success)
            {
                MessageBox.Show("Invalid Contact Must Only Have Numbers", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                clearTextboxes();
                return false;
            }

            return true;
        }

        // Button Click Event to Clear Textboxes
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            clearTextboxes();
        }

        // Button Click Event to Create an Account
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                // Check if the agreeCheckbox is checked
                if (agreeCheckbox.IsChecked == true)
                {
                    // Check if validation is successful
                    if (validation() == true)
                    {
                        // Check if the phone number already exists
                        SqlCommand cmd1 = new SqlCommand("SELECT * FROM  Users_tb WHERE Phone = '" + tbPhone.Text + "'", SqlCon);
                        SqlDataAdapter da = new SqlDataAdapter(cmd1);
                        da.Fill(ds);
                        int i = ds.Tables[0].Rows.Count;

                        // If the phone number exists, show a message
                        if (i > 0)
                        {
                            MessageBox.Show("Mobile Number: " + tbPhone.Text + " already exists");
                            ds.Clear();
                        }
                        else
                        {
                            // Insert new user into the database
                            SqlCommand cmd = new SqlCommand("INSERT INTO Users_tb VALUES (@Name, @Password, @Email, @Phone)", SqlCon);
                            cmd.CommandType = CommandType.Text;
                            cmd.Parameters.AddWithValue("@Name", tbName.Text);
                            cmd.Parameters.AddWithValue("@Email", tbEmail.Text);
                            cmd.Parameters.AddWithValue("@Password", SecureData.HashString(tbPassword.Password));
                            //cmd.Parameters.AddWithValue("@Password", tbPassword.Password);
                            cmd.Parameters.AddWithValue("@Phone", tbPhone.Text);

                            SqlCon.Open();
                            cmd.ExecuteNonQuery();
                            SqlCon.Close();

                            MessageBox.Show("You are Successfully Registered", "Registered", MessageBoxButton.OK, MessageBoxImage.Information);
                            clearTextboxes();

                            // Show the login window
                            Window1 loginWindow = new Window1();
                            loginWindow.Show();
                            this.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Some Fields are Empty.\nPlease fill them", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please agree with the terms and conditions.", "Warning", MessageBoxButton.OK);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                // Close the connection and clear textboxes in the finally block
                SqlCon.Close();
                clearTextboxes();
            }
        }

        // Button Click Event to Navigate to Login Window
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Window1 loginWindow = new Window1();
            loginWindow.Show();
            this.Close();
        }

        private void agreeCheckbox_Click(object sender, RoutedEventArgs e)
        {

        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
