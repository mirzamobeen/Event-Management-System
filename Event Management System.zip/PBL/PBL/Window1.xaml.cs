﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using PBL;

namespace PBL
{
    public partial class Window1 : Window
    {
        // SqlConnection Object for Database Connection
        SqlConnection SqlCon = new SqlConnection(@"Data Source=SHAHZAIB\SQLEXPRESS;Initial Catalog=PBL;Integrated Security=True");

        // Constructor
        public Window1()
        {
            InitializeComponent();
        }

        // Clear Textboxes Method
        public void clearTextboxes()
        {
            tbEmail.Clear();
            tbPassword.Clear();
        }

        // Validation Method for Empty and Whitespace
        public bool validation()
        {
            if (String.IsNullOrEmpty(tbEmail.Text) || String.IsNullOrEmpty(tbPassword.Password))
            {
                return false;
            }
            if (String.IsNullOrWhiteSpace(tbEmail.Text) || String.IsNullOrWhiteSpace(tbPassword.Password))
            {
                return false;
            }
            return true;
        }

        // Button Click Event to Clear Textboxes
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            clearTextboxes();
        }

        // Button Click Event to Open SignUp Window
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            MainWindow SignUpWindow = new MainWindow();
            SignUpWindow.Show();
            this.Close();
        }

        // Button Click Event to Login
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (validation() == false)
            {
                MessageBox.Show("Some Fields are Empty.\nPlease fill them first", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            try
            {
                // Check if the connection is open; if not, open it.
                if (SqlCon.State == ConnectionState.Closed)
                {
                    SqlCon.Open();
                }

                // SQL Query to Check User Credentials
                string query = "SELECT COUNT(1) FROM Users_tb WHERE Email = @Email AND Password = @Password";

                SqlCommand sqlCommand = new SqlCommand(query, SqlCon);

                sqlCommand.CommandType = CommandType.Text;

                sqlCommand.Parameters.AddWithValue("@Email", tbEmail.Text);
                sqlCommand.Parameters.AddWithValue("@Password", SecureData.HashString(tbPassword.Password));

                // Execute the query and get the result count
                int count = Convert.ToInt32(sqlCommand.ExecuteScalar());

                // Check the result count and navigate to the Main Window if credentials are correct
                if (count == 1)
                {
                    Main Home = new Main();
                    Home.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Enter Correct Details");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                // Close the connection in the finally block to ensure it's closed even if an exception occurs.
                SqlCon.Close();
            }
        }
    }
}
