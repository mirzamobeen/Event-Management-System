﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace PBL
{
    public partial class All_Participants : Window
    {
        // SqlConnection Object for Database Connection
        SqlConnection sqlCon = new SqlConnection(@"Data Source=SHAHZAIB\SQLEXPRESS;Initial Catalog=PBL;Integrated Security=True");

        // DataSet to hold data temporarily
        DataSet ds = new DataSet();

        // Constructor
        public All_Participants()
        {
            InitializeComponent();
            LoadGrid();
        }

        // Validation Method for Empty and Whitespace, along with specific pattern checks
        public bool validation()
        {
            if (String.IsNullOrEmpty(tbName.Text) || String.IsNullOrEmpty(tbEmail.Text) || String.IsNullOrEmpty(tbPhone.Text) || String.IsNullOrEmpty(tbEvent.Text))
            {
                return false;
            }
            else if (String.IsNullOrWhiteSpace(tbName.Text) || String.IsNullOrWhiteSpace(tbEmail.Text) || String.IsNullOrWhiteSpace(tbPhone.Text) || String.IsNullOrWhiteSpace(tbEvent.Text))
            {
                return false;
            }
            else if (!Regex.Match(tbName.Text, "^[a-zA-Z]+$").Success)
            {
                MessageBox.Show("Invalid Name Must only have English characters", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                clearTextboxes();
                return false;
            }
            else if (!Regex.Match(tbEmail.Text, "^[a-zA-Z0-9]+@(gmail.com|yahoo.com|hotmail.com)$").Success)
            {
                MessageBox.Show("Not a Valid Email", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                clearTextboxes();
                return false;
            }
            else if (!Regex.Match(tbPhone.Text, "^[0-9]+$").Success)
            {
                MessageBox.Show("Invalid Contact Must Only Have Numbers", "Message", MessageBoxButton.OK, MessageBoxImage.Error);
                clearTextboxes();
                return false;
            }
            return true;
        }

        // Clear Textboxes Method
        public void clearTextboxes()
        {
            tbName.Clear();
            tbEmail.Clear();
            tbPhone.Clear();
            tbEvent.Clear();
        }

        // Load Data into the DataGrid
        public void LoadGrid()
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM Participant", sqlCon))
                {
                    sqlCon.Open();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    datagrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error Not able to load: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        // Button Click Event to Navigate to Participant Window
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Participant Home = new Participant();
            Home.Show();
            this.Close();
        }

        // Button Click Event to Delete a Record
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            sqlCon.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM Participant WHERE PartID= " + tbSearch.Text + " ", sqlCon);
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record has been deleted", "Deleted", MessageBoxButton.OK, MessageBoxImage.Information);
                clearTextboxes();
                LoadGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Not Deleted" + ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        // Button Click Event to Clear Textboxes
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            clearTextboxes();
        }

        // Button Click Event to Update a Record
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            sqlCon.Open();
            SqlCommand cmd = new SqlCommand("UPDATE Participant SET Name = " +
                "'" + tbName.Text + "', Email='" + tbEmail.Text + "', Phone = '"
                + tbPhone.Text + "', EventID= '" + tbEvent.Text + "'" + "" +
                " WHERE PartID = '" + tbSearch.Text + "'", sqlCon);
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record has been Updated Successfully ", "Updated", MessageBoxButton.OK, MessageBoxImage.Information);
                clearTextboxes();
                LoadGrid();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        // Button Click Event to Reload Data into the DataGrid
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            LoadGrid();
        }

        // Button Click Event to Search and Display Matching Records
        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            try
            {
                sqlCon.Open();
                String query = "SELECT * FROM Participant WHERE PartID LIKE @PartID";

                using (SqlCommand cmd = new SqlCommand(query, sqlCon))
                {
                    cmd.Parameters.AddWithValue("@PartID", "%" + tbSearch.Text + "");
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    datagrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }
        }
    }
}
